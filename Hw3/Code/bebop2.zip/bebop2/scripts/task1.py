#!/usr/bin/env python
import math
import rospy

from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from bebop_msgs.msg import Ardrone3PilotingStateFlyingStateChanged
from bebop_msgs.msg import Ardrone3PilotingStatePositionChanged
from nav_msgs.msg import Odometry

goal = [0, 6, 2]
kp = 0.03


class ControllerNode():
    def __init__(self):
        # Creates a node with name 'takeoff_node' and make sure it is a
        # unique node (using anonymous=True).
        rospy.init_node('controller_node', anonymous=True)

        # Test
        self.pos_sub = rospy.Subscriber('/bebop/odom', Odometry, self.printpos)

        # cmd msg
        self.cmdvel_publisher = rospy.Publisher('/bebop/cmd_vel',
                                                  Twist, queue_size=10)

        self.state=None
        self.rate = rospy.Rate(10)

    def printpos(self, data):
        global kp
        y = data.pose.pose.position.x
        x = -data.pose.pose.position.y
        z = data.pose.pose.position.z

        ro_x = goal[0] - x
        ro_y = goal[1] - y
        ro_z = goal[2] - z

        ro = math.sqrt(((goal[0]-x)**2)+((goal[1]-y)**2)+((goal[2]-z)**2))

        v_x = kp*ro_x
        v_y = kp*ro_y
        v_z = kp*ro_z



        print(x,y,z)
        v = kp*ro

        if ro < 0.5:
            kp = 0
        twist = Twist()
        twist.linear.x = v_x
        twist.linear.y = v_y
        twist.linear.z = v_z
        twist.angular.x = 0 
        twist.angular.y = 0 
        twist.angular.z = 0

        self.cmdvel_publisher.publish(twist)

        print(ro)

if __name__ == '__main__':

    try:
        node = ControllerNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    


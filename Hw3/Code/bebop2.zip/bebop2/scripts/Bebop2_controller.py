#!/usr/bin/env python
import math
import rospy

from takeoff import TakeOffNode
from plot_maker import PlotMaker

from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from bebop_msgs.msg import Ardrone3PilotingStateFlyingStateChanged
from bebop_msgs.msg import Ardrone3PilotingStatePositionChanged
from nav_msgs.msg import Odometry


class controller():

	def __init__(self, goals, kp):
	    #rospy.init_node('controller_node', anonymous=True)
	    print('Start of program')

	    self.pm = PlotMaker(self)

	    self.goals = goals
	    self.kp = kp

	    self.kp_yaw = 0.1

	    self.goal_index = 0
	    self.current_goal = [0,0,2]

	    self.state = None
	    self.take_off_finished = False

	    # Subscribe to odometry data from bebob2
	    self.pos_sub = rospy.Subscriber('/bebop/odom', Odometry, self.update_pos)
	    
	    # Subscribe to FlyingStateChanged
	    self.pilotingstate_subscriber = rospy.Subscriber('/bebop/states/ardrone3/PilotingState/FlyingStateChanged',
                                                Ardrone3PilotingStateFlyingStateChanged, self.update_state)

	    # cmd msg
	    self.cmdvel_publisher = rospy.Publisher('/bebop/cmd_vel', Twist, queue_size=10)


	def quaternion_to_euler(self,x,y,z,w):
			t0 = 2*(w*x+y*z)
			t1 = 1-2*(x*x+y*y)
			X = math.degrees(math.atan2(t0,t1))

			t2 = 2*(w*y-z*x)
			t2 = +1.0 if t2 > +1.0 else t2
			t2 = -1.0 if t2 < -1.0 else t2
			Y = math.degrees(math.asin(t2))

			t3 = 2*(w*z+x*y)
			t4 = 1-2*(y*y+z*z)
			Z = math.degrees(math.atan2(t3, t4))

			# X=roll Y=pitch Z=yaw
			pitch = math.atan2(t0, t1)
			yaw = math.asin(t2)
			roll = math.atan2(t3,t4)

			return pitch, yaw, roll


   	def update_state(self, message):
		self.state = message.state

		# Check to see if takeoff is complete
		if self.state == 2:
			self.take_off_finished = True


	def update_pos(self, data):

		if self.take_off_finished:

		    
			# For some reason x and y are inverted and x(y) is negative??? smh
		    y = data.pose.pose.position.x
		    x = -data.pose.pose.position.y
		    z = data.pose.pose.position.z

		    # Distance to goal in the three dimensions
		    ro_x = self.current_goal[0] - x
		    ro_y = self.current_goal[1] - y
		    ro_z = self.current_goal[2] - z

		    # Euclidean distance in three dimensions
		    ro = math.sqrt(((self.current_goal[0]-x)**2)+((self.current_goal[1]-y)**2)
		    	+((self.current_goal[2]-z)**2))

		    v_x = self.kp*ro_x
		    v_y = self.kp*ro_y
		    v_z = self.kp*ro_z


		    # Tried to do something about yaw.. 
		    # error_yaw = 0.5-eul[2]

		    v = self.kp*ro
		    #v_yaw = self.kp_yaw*error_yaw

		    # If distance to target is under xx set next goal
		    if ro < 0.2:
			    self.goal_index = self.goal_index + 1

			    if self.goal_index == len(self.goals):
				    self.goal_index = 0
				    self.pm.make_dist_to_target_plot()
				    self.pm.make_pos_plot()

			    self.current_goal = self.goals[self.goal_index]


		    cmd = Twist()
		    cmd.linear.x = v_x
		    cmd.linear.y = v_y
		    cmd.linear.z = v_z
		    cmd.angular.x = 0 
		    cmd.angular.y = 0 
		    cmd.angular.z = 0

		    self.cmdvel_publisher.publish(cmd)

		    #print(x,y,z)
		    print(ro)
	

	def get_current_goal(self):
		return self.current_goal


	


if __name__ == '__main__':
    try:
    	goal = [[0,0,2], [0,6,2], [6,6,2], [6,0,2], [0,0,2]]
        
        takeoff_node = TakeOffNode()
        controller = controller(goal, 0.1)

        takeoff_node.takeoff()

        rospy.spin()


    except rospy.ROSInterruptException:
        pass


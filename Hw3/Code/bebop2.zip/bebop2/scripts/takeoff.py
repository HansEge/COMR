#!/usr/bin/env python

import rospy
from std_msgs.msg import Empty
from bebop_msgs.msg import Ardrone3PilotingStateFlyingStateChanged


class TakeOffNode():
    def __init__(self):
        # Creates a node with name 'takeoff_node' and make sure it is a
        # unique node (using anonymous=True).
        rospy.init_node('takeoff_node', anonymous=True)

        # Publisher which will publish to the topic '/bebop/takeoff'.
        self.takeoff_publisher = rospy.Publisher('/bebop/takeoff',
                                                  Empty, queue_size=10)

        # A subscriber to the topic '/bebop/states/ardrone3/PilotingState/FlyingStateChanged'. self.update_state is called
        # when a message of type Ardrone3PilotingStateFlyingStateChanged is received.
        self.pilotingstate_subscriber = rospy.Subscriber('/bebop/states/ardrone3/PilotingState/FlyingStateChanged',
                                                Ardrone3PilotingStateFlyingStateChanged, self.update_state)
        self.state=None
        self.rate = rospy.Rate(10)   

    def takeoff(self):
        #while not rospy.is_shutdown():
        while self.state != 2: 
            hello_str = "Takeoff command has been sent %s" % rospy.get_time()
            rospy.loginfo(hello_str)
            self.takeoff_publisher.publish(Empty())
            self.rate.sleep()

        print("Takeoff is done!")

    def update_state(self, message):
        print(message.state)
        self.state = message.state

    def get_state():
        return self.state

#!/usr/bin/env python
import math
import rospy

import time
import datetime

import plotly.graph_objects as go

from nav_msgs.msg import Odometry


class PlotMaker():
	def __init__(self, controller):

		# Subscribe to odometry data from bebob2
	    self.pos_sub = rospy.Subscriber('/bebop/odom', Odometry, self.add_data_to_lists)

	    # [x,y,z,time]
	    self.coords_over_time = [[0,0,0,0]]

	    # [ro, time]
	    self.error_over_time = [[0,0]]

	    # Start of simulation
	    self.t0 = datetime.datetime.now()

    	# Reference to controller
	    self.controller = controller


	def add_data_to_lists(self, data):

		# For some reason x and y are inverted and x(y) is negative??? smh
	    y = data.pose.pose.position.x
	    x = -data.pose.pose.position.y
	    z = data.pose.pose.position.z

	    ro = math.sqrt(((self.controller.get_current_goal()[0]-x)**2)+((self.controller.get_current_goal()[1]-y)**2)
		    	+((self.controller.get_current_goal()[2]-z)**2))

	    t1 = datetime.datetime.now()
	    duration = t1 - self.t0
	    time = float(duration.total_seconds())

	    self.coords_over_time.append([x,y,z,time])
	    self.error_over_time.append([ro,time])



	def make_dist_to_target_plot(self):
		print("Printing error over time plot")

		fig1 = go.Figure()

		fig1.add_trace(go.Scatter(
			x=[row[1] for row in self.error_over_time],
			y=[row[0] for row in self.error_over_time],
			name="Ro"
			))

		fig1.update_layout(
			title="Error to target over time",
			xaxis_title="Time",
			yaxis_title="Error(Ro)"
			)

		fig1.show()

	def make_pos_plot(self):
		print("Printing position of robot over time plot")

		fig1 = go.Figure()

		fig1.add_trace(go.Scatter(
			x=[row[3] for row in self.coords_over_time],
			y=[row[0] for row in self.coords_over_time],
			name="x-coordinates"
			))

		fig1.add_trace(go.Scatter(
			x=[row[3] for row in self.coords_over_time],
			y=[row[1] for row in self.coords_over_time],
			name="y-coordinates"
			))

		fig1.add_trace(go.Scatter(
			x=[row[3] for row in self.coords_over_time],
			y=[row[2] for row in self.coords_over_time],
			name="z-coordinates"
			))

		fig1.update_layout(
			title="Position over time",
			xaxis_title="Time",
			yaxis_title="Coords"
			)

		fig1.show()

